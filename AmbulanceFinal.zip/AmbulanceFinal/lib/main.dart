import 'package:flutter/material.dart';
import 'screens/ambulance_dashboard.dart';
import 'screens/traffic_control_dashboard.dart';
import 'screens/road_user_interface.dart';
import 'screens/hospital_dashboard.dart';
import 'widgets/app_drawer.dart';

void main() {
  runApp(EmergencyResponseApp());
}

class EmergencyResponseApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Emergency Response System',
      theme: ThemeData(
        primarySwatch: Colors.red,
        brightness: Brightness.light,
        useMaterial3: true,
      ),
      darkTheme: ThemeData(
        primarySwatch: Colors.red,
        brightness: Brightness.dark,
        useMaterial3: true,
      ),
      themeMode: ThemeMode.system,
      home: DashboardSelector(),
    );
  }
}

class DashboardSelector extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Emergency Response System'),
        backgroundColor: Colors.red,
        foregroundColor: Colors.white,
      ),
      drawer: AppDrawer(currentScreen: 'home'),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              'Select Dashboard',
              style: Theme.of(context).textTheme.headlineMedium,
            ),
            SizedBox(height: 40),
            DashboardButton(
              title: 'Ambulance Driver',
              icon: Icons.local_hospital,
              color: Colors.red,
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => AmbulanceDashboard()),
              ),
            ),
            DashboardButton(
              title: 'Traffic Control Center',
              icon: Icons.traffic,
              color: Colors.blue,
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => TrafficControlDashboard()),
              ),
            ),
            DashboardButton(
              title: 'Road User Interface',
              icon: Icons.directions_car,
              color: Colors.green,
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => RoadUserInterface()),
              ),
            ),
            DashboardButton(
              title: 'Hospital Emergency',
              icon: Icons.local_hospital,
              color: Colors.purple,
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => HospitalDashboard()),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class DashboardButton extends StatelessWidget {
  final String title;
  final IconData icon;
  final Color color;
  final VoidCallback onTap;

  const DashboardButton({
    required this.title,
    required this.icon,
    required this.color,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0, horizontal: 24.0),
      child: ElevatedButton(
        onPressed: onTap,
        style: ElevatedButton.styleFrom(
          backgroundColor: color,
          foregroundColor: Colors.white,
          minimumSize: Size(double.infinity, 70),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(15),
          ),
        ),
        child: Row(
          children: [
            Icon(icon, size: 30),
            SizedBox(width: 16),
            Text(
              title,
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
          ],
        ),
      ),
    );
  }
}

