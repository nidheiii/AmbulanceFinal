import 'package:flutter/material.dart';
import '../widgets/incoming_ambulance_tracker.dart';
import '../widgets/bed_availability.dart';
import '../widgets/staff_alerts.dart';
import '../widgets/direct_communication.dart';
import '../widgets/app_drawer.dart';

class HospitalDashboard extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Hospital Emergency Dashboard'),
        backgroundColor: Colors.purple,
        foregroundColor: Colors.white,
      ),
      drawer: AppDrawer(currentScreen: 'hospital'),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            children: [
              // Top row - Incoming ambulances and bed availability
              Expanded(
                flex: 2,
                child: Row(
                  children: [
                    // Incoming ambulance tracker
                    Expanded(
                      flex: 3,
                      child: IncomingAmbulanceTracker(
                        incomingAmbulances: [
                          {
                            'id': 'AMB-1234',
                            'eta': '3 min',
                            'patient': 'Male, 45',
                            'condition': 'Cardiac Arrest',
                            'priority': 'Critical',
                          },
                          {
                            'id': 'AMB-5678',
                            'eta': '8 min',
                            'patient': 'Female, 32',
                            'condition': 'Trauma',
                            'priority': 'High',
                          },
                          {
                            'id': 'AMB-9012',
                            'eta': '12 min',
                            'patient': 'Child, 8',
                            'condition': 'Respiratory',
                            'priority': 'Medium',
                          },
                        ],
                      ),
                    ),
                    SizedBox(width: 8),
                    // Bed availability
                    Expanded(
                      flex: 2,
                      child: BedAvailability(
                        regularBeds: 12,
                        regularTotal: 30,
                        icuBeds: 4,
                        icuTotal: 10,
                        traumaBeds: 2,
                        traumaTotal: 5,
                        pediatricBeds: 6,
                        pediatricTotal: 15,
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(height: 8),
              // Bottom row - Staff alerts and direct communication
              Expanded(
                flex: 1,
                child: Row(
                  children: [
                    // Staff alerts
                    Expanded(
                      child: StaffAlerts(
                        alerts: [
                          {
                            'type': 'Cardiac Team',
                            'message': 'Cardiac arrest patient arriving in 3 min',
                            'priority': 'Critical',
                          },
                          {
                            'type': 'Trauma Team',
                            'message': 'Trauma patient arriving in 8 min',
                            'priority': 'High',
                          },
                          {
                            'type': 'Pediatric',
                            'message': 'Child with respiratory issues arriving in 12 min',
                            'priority': 'Medium',
                          },
                        ],
                      ),
                    ),
                    SizedBox(width: 8),
                    // Direct communication
                    Expanded(
                      child: DirectCommunication(
                        ambulances: [
                          {'id': 'AMB-1234', 'driver': 'John Smith', 'status': 'En Route'},
                          {'id': 'AMB-5678', 'driver': 'Sarah Johnson', 'status': 'En Route'},
                          {'id': 'AMB-9012', 'driver': 'Mike Davis', 'status': 'En Route'},
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

