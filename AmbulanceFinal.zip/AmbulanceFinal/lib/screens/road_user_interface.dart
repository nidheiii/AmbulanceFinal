import 'package:flutter/material.dart';
import '../widgets/map_widget.dart';
import '../widgets/ambulance_alert.dart';
import '../widgets/alternate_route.dart';
import '../widgets/infotainment_sync.dart';
import '../widgets/smart_signal_indicator.dart';
import '../widgets/app_drawer.dart';

class RoadUserInterface extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Road User Interface'),
        backgroundColor: Colors.green,
        foregroundColor: Colors.white,
      ),
      drawer: AppDrawer(currentScreen: 'road'),
      body: SafeArea(
        child: Column(
          children: [
            // Ambulance alert banner (only shows when ambulance is nearby)
            AmbulanceAlert(
              distance: '300m',
              direction: 'behind you',
              eta: '15 seconds',
            ),
            // Map with current location and route
            Expanded(
              flex: 3,
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: MapWidget(
                  isAmbulance: false,
                  showControls: false,
                ),
              ),
            ),
            // Bottom controls
            Expanded(
              flex: 1,
              child: Container(
                padding: EdgeInsets.all(8.0),
                child: Row(
                  children: [
                    Expanded(
                      child: AlternateRoute(
                        originalEta: '18 min',
                        newEta: '15 min',
                        distance: '7.2 km',
                      ),
                    ),
                    SizedBox(width: 8),
                    Expanded(
                      child: Row(
                        children: [
                          Expanded(
                            child: InfotainmentSync(),
                          ),
                          SizedBox(width: 8),
                          Expanded(
                            child: SmartSignalIndicator(
                              nextSignal: 'Main St & 5th Ave',
                              status: 'Green',
                              distance: '0.4 km',
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

