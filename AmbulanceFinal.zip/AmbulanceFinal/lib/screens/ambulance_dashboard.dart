import 'package:flutter/material.dart';
import '../widgets/map_widget.dart';
import '../widgets/route_suggestion.dart';
import '../widgets/traffic_signal_control.dart';
import '../widgets/emergency_alerts.dart';
import '../widgets/hospital_availability.dart';
import '../widgets/roadblock_alerts.dart';
import '../widgets/app_drawer.dart';

class AmbulanceDashboard extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Ambulance Driver Dashboard'),
        backgroundColor: Colors.red,
        foregroundColor: Colors.white,
      ),
      drawer: AppDrawer(currentScreen: 'ambulance'),
      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              flex: 3,
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: MapWidget(
                  isAmbulance: true,
                  showControls: true,
                ),
              ),
            ),
            Expanded(
              flex: 2,
              child: Container(
                padding: EdgeInsets.all(8.0),
                child: GridView.count(
                  crossAxisCount: 2,
                  childAspectRatio: 1.5,
                  mainAxisSpacing: 10,
                  crossAxisSpacing: 10,
                  children: [
                    RouteSuggestion(
                      destination: 'City Hospital',
                      eta: '8 min',
                      distance: '3.2 km',
                    ),
                    TrafficSignalControl(
                      status: 'Active',
                      nextSignal: 'Main St & 5th Ave',
                      distance: '0.8 km',
                    ),
                    EmergencyAlerts(),
                    HospitalAvailability(
                      nearbyHospitals: [
                        {'name': 'City Hospital', 'beds': 5, 'icu': 2, 'distance': '3.2 km'},
                        {'name': 'General Hospital', 'beds': 8, 'icu': 1, 'distance': '5.7 km'},
                      ],
                    ),
                    RoadblockAlerts(
                      alerts: [
                        {'type': 'Accident', 'location': 'Main St & 3rd Ave', 'impact': 'High'},
                        {'type': 'Construction', 'location': 'Park Rd', 'impact': 'Medium'},
                      ],
                    ),
                    Container(
                      decoration: BoxDecoration(
                        color: Colors.red.shade100,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.phone_in_talk, size: 40, color: Colors.red),
                          SizedBox(height: 8),
                          Text(
                            'Emergency Call',
                            style: TextStyle(fontWeight: FontWeight.bold),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

