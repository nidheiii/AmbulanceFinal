import 'package:flutter/material.dart';
import '../widgets/map_widget.dart';
import '../widgets/traffic_signal_grid.dart';
import '../widgets/congestion_warnings.dart';
import '../widgets/manual_override.dart';
import '../widgets/violation_detection.dart';
import '../widgets/app_drawer.dart';

class TrafficControlDashboard extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Traffic Control Center Dashboard'),
        backgroundColor: Colors.blue,
        foregroundColor: Colors.white,
      ),
      drawer: AppDrawer(currentScreen: 'traffic'),
      body: SafeArea(
        child: Row(
          children: [
            // Left panel - Map with active ambulances
            Expanded(
              flex: 3,
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Column(
                  children: [
                    Expanded(
                      child: MapWidget(
                        isAmbulance: false,
                        showControls: true,
                        showAllAmbulances: true,
                      ),
                    ),
                    SizedBox(height: 8),
                    Container(
                      height: 100,
                      decoration: BoxDecoration(
                        color: Colors.blue.shade100,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Active Emergency Vehicles',
                              style: TextStyle(fontWeight: FontWeight.bold),
                            ),
                            SizedBox(height: 8),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceAround,
                              children: [
                                _buildStatCard('Ambulances', '12', Icons.local_hospital),
                                _buildStatCard('Fire Trucks', '4', Icons.local_fire_department),
                                _buildStatCard('Police', '8', Icons.local_police),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            // Right panel - Controls and alerts
            Expanded(
              flex: 2,
              child: Container(
                padding: EdgeInsets.all(8.0),
                child: Column(
                  children: [
                    Expanded(
                      child: TrafficSignalGrid(),
                    ),
                    SizedBox(height: 8),
                    Expanded(
                      child: CongestionWarnings(),
                    ),
                    SizedBox(height: 8),
                    Expanded(
                      child: Row(
                        children: [
                          Expanded(
                            child: ManualOverride(),
                          ),
                          SizedBox(width: 8),
                          Expanded(
                            child: ViolationDetection(),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStatCard(String title, String count, IconData icon) {
    return Column(
      children: [
        Icon(icon, color: Colors.blue),
        SizedBox(height: 4),
        Text(count, style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
        Text(title, style: TextStyle(fontSize: 12)),
      ],
    );
  }
}

