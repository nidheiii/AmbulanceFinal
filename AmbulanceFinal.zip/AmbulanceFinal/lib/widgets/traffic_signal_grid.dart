import 'package:flutter/material.dart';

class TrafficSignalGrid extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.blue.shade100,
        borderRadius: BorderRadius.circular(10),
      ),
      padding: EdgeInsets.all(12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.traffic, color: Colors.blue),
              SizedBox(width: 8),
              Text(
                'Traffic Signal Control',
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 16,
                ),
              ),
            ],
          ),
          Divider(),
          Expanded(
            child: GridView.builder(
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 3,
                childAspectRatio: 1.0,
                crossAxisSpacing: 8,
                mainAxisSpacing: 8,
              ),
              itemCount: 9,
              itemBuilder: (context, index) {
                // Randomly assign signal status for demo
                final statuses = ['green', 'red', 'yellow'];
                final status = statuses[index % 3];
                
                return TrafficSignalTile(
                  intersection: 'Intersection ${index + 1}',
                  status: status,
                  hasEmergency: index == 2 || index == 5,
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

class TrafficSignalTile extends StatelessWidget {
  final String intersection;
  final String status;
  final bool hasEmergency;

  const TrafficSignalTile({
    required this.intersection,
    required this.status,
    this.hasEmergency = false,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(
          color: hasEmergency ? Colors.red : Colors.transparent,
          width: 2,
        ),
      ),
      padding: EdgeInsets.all(8),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 20,
            height: 20,
            decoration: BoxDecoration(
              color: _getStatusColor(status),
              shape: BoxShape.circle,
            ),
          ),
          SizedBox(height: 4),
          Text(
            intersection,
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 10),
          ),
          if (hasEmergency)
            Container(
              margin: EdgeInsets.only(top: 4),
              padding: EdgeInsets.symmetric(horizontal: 4, vertical: 2),
              decoration: BoxDecoration(
                color: Colors.red,
                borderRadius: BorderRadius.circular(4),
              ),
              child: Text(
                'EMERGENCY',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 8,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
        ],
      ),
    );
  }

  Color _getStatusColor(String status) {
    switch (status.toLowerCase()) {
      case 'green':
        return Colors.green;
      case 'red':
        return Colors.red;
      case 'yellow':
        return Colors.amber;
      default:
        return Colors.grey;
    }
  }
}

