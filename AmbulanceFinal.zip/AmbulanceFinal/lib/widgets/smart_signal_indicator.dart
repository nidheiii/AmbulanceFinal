import 'package:flutter/material.dart';

class SmartSignalIndicator extends StatelessWidget {
  final String nextSignal;
  final String status;
  final String distance;

  const SmartSignalIndicator({
    required this.nextSignal,
    required this.status,
    required this.distance,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: _getStatusColor(status).withOpacity(0.2),
        borderRadius: BorderRadius.circular(10),
      ),
      padding: EdgeInsets.all(12),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 30,
            height: 30,
            decoration: BoxDecoration(
              color: _getStatusColor(status),
              shape: BoxShape.circle,
            ),
            child: Center(
              child: Icon(
                _getStatusIcon(status),
                color: Colors.white,
                size: 20,
              ),
            ),
          ),
          SizedBox(height: 8),
          Text(
            nextSignal,
            style: TextStyle(
              fontWeight: FontWeight.bold,
              fontSize: 12,
            ),
            textAlign: TextAlign.center,
          ),
          Text(
            distance,
            style: TextStyle(fontSize: 10),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  Color _getStatusColor(String status) {
    switch (status.toLowerCase()) {
      case 'green':
        return Colors.green;
      case 'red':
        return Colors.red;
      case 'yellow':
        return Colors.amber;
      default:
        return Colors.grey;
    }
  }

  IconData _getStatusIcon(String status) {
    switch (status.toLowerCase()) {
      case 'green':
        return Icons.play_arrow;
      case 'red':
        return Icons.stop;
      case 'yellow':
        return Icons.warning;
      default:
        return Icons.help;
    }
  }
}

