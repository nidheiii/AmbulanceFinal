import 'package:flutter/material.dart';

class AmbulanceAlert extends StatelessWidget {
  final String distance;
  final String direction;
  final String eta;

  const AmbulanceAlert({
    required this.distance,
    required this.direction,
    required this.eta,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.symmetric(vertical: 12, horizontal: 16),
      decoration: BoxDecoration(
        color: Colors.red,
      ),
      child: Row(
        children: [
          Icon(
            Icons.notifications_active,
            color: Colors.white,
            size: 24,
          ),
          SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'EMERGENCY VEHICLE APPROACHING',
                  style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 16,
                  ),
                ),
                Text(
                  'Ambulance $distance $direction - ETA $eta',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 14,
                  ),
                ),
              ],
            ),
          ),
          ElevatedButton(
            onPressed: () {},
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.white,
              foregroundColor: Colors.red,
              padding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            ),
            child: Text('Move Aside'),
          ),
        ],
      ),
    );
  }
}

