import 'package:flutter/material.dart';

class TrafficSignalControl extends StatelessWidget {
  final String status;
  final String nextSignal;
  final String distance;

  const TrafficSignalControl({
    required this.status,
    required this.nextSignal,
    required this.distance,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.green.shade100,
        borderRadius: BorderRadius.circular(10),
      ),
      padding: EdgeInsets.all(12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.traffic, color: Colors.green),
              SizedBox(width: 8),
              Text(
                'Signal Preemption',
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 16,
                ),
              ),
            ],
          ),
          Divider(),
          Row(
            children: [
              Container(
                padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: Colors.green,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Text(
                  status,
                  style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 12,
                  ),
                ),
              ),
            ],
          ),
          SizedBox(height: 8),
          Text(
            'Next Signal:',
            style: TextStyle(fontWeight: FontWeight.bold),
          ),
          Text(nextSignal),
          SizedBox(height: 4),
          Row(
            children: [
              Icon(Icons.straighten, size: 16, color: Colors.green.shade700),
              SizedBox(width: 4),
              Text(distance),
            ],
          ),
        ],
      ),
    );
  }
}

