import 'package:flutter/material.dart';
import '../screens/ambulance_dashboard.dart';
import '../screens/traffic_control_dashboard.dart';
import '../screens/road_user_interface.dart';
import '../screens/hospital_dashboard.dart';

class AppDrawer extends StatelessWidget {
  final String currentScreen;

  const AppDrawer({
    Key? key,
    required this.currentScreen,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: Column(
        children: [
          // Drawer header with app logo and name
          DrawerHeader(
            decoration: BoxDecoration(
              color: _getHeaderColor(currentScreen),
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  _getHeaderColor(currentScreen),
                  _getHeaderColor(currentScreen).withOpacity(0.7),
                ],
              ),
            ),
            child: Container(
              width: double.infinity,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  CircleAvatar(
                    backgroundColor: Colors.white,
                    radius: 30,
                    child: Icon(
                      _getHeaderIcon(currentScreen),
                      color: _getHeaderColor(currentScreen),
                      size: 30,
                    ),
                  ),
                  SizedBox(height: 10),
                  Text(
                    'Emergency Response',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  Text(
                    _getSubtitle(currentScreen),
                    style: TextStyle(
                      color: Colors.white.withOpacity(0.9),
                      fontSize: 14,
                    ),
                  ),
                ],
              ),
            ),
          ),
          
          // Navigation items
          _buildDrawerItem(
            context: context,
            icon: Icons.local_hospital,
            title: 'Ambulance Driver',
            isSelected: currentScreen == 'ambulance',
            color: Colors.red,
            onTap: () {
              if (currentScreen != 'ambulance') {
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(builder: (context) => AmbulanceDashboard()),
                );
              } else {
                Navigator.pop(context);
              }
            },
          ),
          
          _buildDrawerItem(
            context: context,
            icon: Icons.traffic,
            title: 'Traffic Control',
            isSelected: currentScreen == 'traffic',
            color: Colors.blue,
            onTap: () {
              if (currentScreen != 'traffic') {
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(builder: (context) => TrafficControlDashboard()),
                );
              } else {
                Navigator.pop(context);
              }
            },
          ),
          
          _buildDrawerItem(
            context: context,
            icon: Icons.directions_car,
            title: 'Road User',
            isSelected: currentScreen == 'road',
            color: Colors.green,
            onTap: () {
              if (currentScreen != 'road') {
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(builder: (context) => RoadUserInterface()),
                );
              } else {
                Navigator.pop(context);
              }
            },
          ),
          
          _buildDrawerItem(
            context: context,
            icon: Icons.local_hospital,
            title: 'Hospital Emergency',
            isSelected: currentScreen == 'hospital',
            color: Colors.purple,
            onTap: () {
              if (currentScreen != 'hospital') {
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(builder: (context) => HospitalDashboard()),
                );
              } else {
                Navigator.pop(context);
              }
            },
          ),
          
          Divider(),
          
          // Settings and help section
          _buildDrawerItem(
            context: context,
            icon: Icons.settings,
            title: 'Settings',
            isSelected: false,
            color: Colors.grey.shade700,
            onTap: () {
              // Navigate to settings
              Navigator.pop(context);
            },
          ),
          
          _buildDrawerItem(
            context: context,
            icon: Icons.help,
            title: 'Help & Support',
            isSelected: false,
            color: Colors.grey.shade700,
            onTap: () {
              // Navigate to help
              Navigator.pop(context);
            },
          ),
          
          Spacer(),
          
          // User profile section at bottom
          Container(
            padding: EdgeInsets.symmetric(vertical: 16, horizontal: 16),
            decoration: BoxDecoration(
              border: Border(
                top: BorderSide(color: Colors.grey.shade300),
              ),
            ),
            child: Row(
              children: [
                CircleAvatar(
                  backgroundColor: Colors.grey.shade200,
                  child: Icon(Icons.person, color: Colors.grey.shade700),
                ),
                SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'John Smith',
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                      Text(
                        'Emergency Responder',
                        style: TextStyle(fontSize: 12, color: Colors.grey),
                      ),
                    ],
                  ),
                ),
                IconButton(
                  icon: Icon(Icons.logout, color: Colors.grey),
                  onPressed: () {
                    // Logout functionality
                  },
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDrawerItem({
    required BuildContext context,
    required IconData icon,
    required String title,
    required bool isSelected,
    required Color color,
    required VoidCallback onTap,
  }) {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 8, vertical: 2),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(8),
        color: isSelected ? color.withOpacity(0.15) : Colors.transparent,
      ),
      child: ListTile(
        leading: Icon(
          icon,
          color: isSelected ? color : Colors.grey.shade700,
        ),
        title: Text(
          title,
          style: TextStyle(
            color: isSelected ? color : Colors.black,
            fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
          ),
        ),
        trailing: isSelected
            ? Container(
                width: 5,
                height: 30,
                decoration: BoxDecoration(
                  color: color,
                  borderRadius: BorderRadius.circular(5),
                ),
              )
            : null,
        onTap: onTap,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(8),
        ),
        dense: true,
        visualDensity: VisualDensity.compact,
      ),
    );
  }

  Color _getHeaderColor(String screen) {
    switch (screen) {
      case 'ambulance':
        return Colors.red;
      case 'traffic':
        return Colors.blue;
      case 'road':
        return Colors.green;
      case 'hospital':
        return Colors.purple;
      default:
        return Colors.grey;
    }
  }

  IconData _getHeaderIcon(String screen) {
    switch (screen) {
      case 'ambulance':
        return Icons.local_hospital;
      case 'traffic':
        return Icons.traffic;
      case 'road':
        return Icons.directions_car;
      case 'hospital':
        return Icons.local_hospital;
      default:
        return Icons.dashboard;
    }
  }

  String _getSubtitle(String screen) {
    switch (screen) {
      case 'ambulance':
        return 'Ambulance Driver Dashboard';
      case 'traffic':
        return 'Traffic Control Center';
      case 'road':
        return 'Road User Interface';
      case 'hospital':
        return 'Hospital Emergency Dashboard';
      default:
        return 'Dashboard';
    }
  }
}

