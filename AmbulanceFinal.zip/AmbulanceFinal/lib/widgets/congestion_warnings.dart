import 'package:flutter/material.dart';

class CongestionWarnings extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.orange.shade100,
        borderRadius: BorderRadius.circular(10),
      ),
      padding: EdgeInsets.all(12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.warning, color: Colors.orange),
              SizedBox(width: 8),
              Text(
                'Congestion & Roadblocks',
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 16,
                ),
              ),
            ],
          ),
          Divider(),
          Expanded(
            child: ListView(
              padding: EdgeInsets.zero,
              children: [
                _buildWarningItem(
                  icon: Icons.car_crash,
                  title: 'Accident',
                  location: 'Main St & 3rd Ave',
                  impact: 'High',
                  color: Colors.red,
                ),
                _buildWarningItem(
                  icon: Icons.construction,
                  title: 'Construction',
                  location: 'Park Rd',
                  impact: 'Medium',
                  color: Colors.orange,
                ),
                _buildWarningItem(
                  icon: Icons.event,
                  title: 'Public Event',
                  location: 'City Center',
                  impact: 'Low',
                  color: Colors.yellow.shade700,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildWarningItem({
    required IconData icon,
    required String title,
    required String location,
    required String impact,
    required Color color,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8.0),
      child: Row(
        children: [
          Container(
            padding: EdgeInsets.all(6),
            decoration: BoxDecoration(
              color: color,
              shape: BoxShape.circle,
            ),
            child: Icon(
              icon,
              size: 16,
              color: Colors.white,
            ),
          ),
          SizedBox(width: 8),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
                Text(
                  location,
                  style: TextStyle(fontSize: 12),
                ),
              ],
            ),
          ),
          ElevatedButton(
            onPressed: () {},
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.blue,
              foregroundColor: Colors.white,
              padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
              minimumSize: Size(0, 0),
              textStyle: TextStyle(fontSize: 12),
            ),
            child: Text('Reroute'),
          ),
        ],
      ),
    );
  }
}

