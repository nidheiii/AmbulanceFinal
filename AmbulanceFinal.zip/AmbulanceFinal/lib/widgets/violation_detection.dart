import 'package:flutter/material.dart';

class ViolationDetection extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.purple.shade100,
        borderRadius: BorderRadius.circular(10),
      ),
      padding: EdgeInsets.all(12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.report_problem, color: Colors.purple),
              SizedBox(width: 8),
              Text(
                'Violation Detection',
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 16,
                ),
              ),
            ],
          ),
          Divider(),
          Expanded(
            child: ListView(
              padding: EdgeInsets.zero,
              children: [
                _buildViolationItem(
                  location: 'Main St & 5th Ave',
                  time: '2 min ago',
                  type: 'Blocking Emergency Lane',
                ),
                _buildViolationItem(
                  location: 'Park Rd',
                  time: '5 min ago',
                  type: 'Ignoring Emergency Signal',
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildViolationItem({
    required String location,
    required String time,
    required String type,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8.0),
      child: Row(
        children: [
          Container(
            padding: EdgeInsets.all(6),
            decoration: BoxDecoration(
              color: Colors.purple,
              shape: BoxShape.circle,
            ),
            child: Icon(
              Icons.camera_alt,
              size: 16,
              color: Colors.white,
            ),
          ),
          SizedBox(width: 8),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  type,
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12),
                ),
                Text(
                  location,
                  style: TextStyle(fontSize: 11),
                ),
                Text(
                  time,
                  style: TextStyle(fontSize: 10, color: Colors.grey),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

