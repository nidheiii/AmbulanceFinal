import 'package:flutter/material.dart';

class RouteSuggestion extends StatelessWidget {
  final String destination;
  final String eta;
  final String distance;

  const RouteSuggestion({
    required this.destination,
    required this.eta,
    required this.distance,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.blue.shade100,
        borderRadius: BorderRadius.circular(10),
      ),
      padding: EdgeInsets.all(12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.directions, color: Colors.blue),
              SizedBox(width: 8),
              Text(
                'Fastest Route',
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 16,
                ),
              ),
            ],
          ),
          Divider(),
          Text(
            destination,
            style: TextStyle(fontWeight: FontWeight.bold),
          ),
          SizedBox(height: 4),
          Row(
            children: [
              Icon(Icons.access_time, size: 16, color: Colors.blue.shade700),
              SizedBox(width: 4),
              Text(eta),
              SizedBox(width: 12),
              Icon(Icons.straighten, size: 16, color: Colors.blue.shade700),
              SizedBox(width: 4),
              Text(distance),
            ],
          ),
          Spacer(),
          Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              ElevatedButton(
                onPressed: () {},
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.blue,
                  foregroundColor: Colors.white,
                  padding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  minimumSize: Size(0, 0),
                ),
                child: Text('Navigate'),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

