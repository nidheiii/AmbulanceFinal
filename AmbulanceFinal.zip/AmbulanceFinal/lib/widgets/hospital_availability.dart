import 'package:flutter/material.dart';

class HospitalAvailability extends StatelessWidget {
  final List<Map<String, dynamic>> nearbyHospitals;

  const HospitalAvailability({
    required this.nearbyHospitals,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.purple.shade100,
        borderRadius: BorderRadius.circular(10),
      ),
      padding: EdgeInsets.all(12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.local_hospital, color: Colors.purple),
              SizedBox(width: 8),
              Text(
                'Hospital Availability',
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 16,
                ),
              ),
            ],
          ),
          Divider(),
          Expanded(
            child: ListView.builder(
              itemCount: nearbyHospitals.length,
              padding: EdgeInsets.zero,
              itemBuilder: (context, index) {
                final hospital = nearbyHospitals[index];
                return Padding(
                  padding: const EdgeInsets.only(bottom: 8.0),
                  child: Row(
                    children: [
                      Expanded(
                        flex: 3,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              hospital['name'],
                              style: TextStyle(fontWeight: FontWeight.bold),
                            ),
                            Text(
                              'Distance: ${hospital['distance']}',
                              style: TextStyle(fontSize: 12),
                            ),
                          ],
                        ),
                      ),
                      Expanded(
                        flex: 2,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            _buildBedInfo('Beds', hospital['beds']),
                            SizedBox(width: 8),
                            _buildBedInfo('ICU', hospital['icu']),
                          ],
                        ),
                      ),
                    ],
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBedInfo(String label, int count) {
    return Column(
      children: [
        Text(
          count.toString(),
          style: TextStyle(
            fontWeight: FontWeight.bold,
            color: count > 0 ? Colors.green : Colors.red,
          ),
        ),
        Text(
          label,
          style: TextStyle(fontSize: 12),
        ),
      ],
    );
  }
}

