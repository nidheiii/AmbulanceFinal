import 'package:flutter/material.dart';

class MapWidget extends StatelessWidget {
  final bool isAmbulance;
  final bool showControls;
  final bool showAllAmbulances;

  const MapWidget({
    this.isAmbulance = false,
    this.showControls = false,
    this.showAllAmbulances = false,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.grey.shade200,
        borderRadius: BorderRadius.circular(10),
      ),
      child: Stack(
        children: [
          // Map placeholder
          Center(
            child: Icon(
              Icons.map,
              size: 100,
              color: Colors.grey.shade400,
            ),
          ),
          
          // Map overlay elements
          Positioned.fill(
            child: CustomPaint(
              painter: MapElementsPainter(
                isAmbulance: isAmbulance,
                showAllAmbulances: showAllAmbulances,
              ),
            ),
          ),
          
          // Controls
          if (showControls)
            Positioned(
              top: 10,
              right: 10,
              child: Column(
                children: [
                  MapControlButton(icon: Icons.add, onPressed: () {}),
                  SizedBox(height: 8),
                  MapControlButton(icon: Icons.remove, onPressed: () {}),
                  SizedBox(height: 8),
                  MapControlButton(icon: Icons.my_location, onPressed: () {}),
                  SizedBox(height: 8),
                  MapControlButton(icon: Icons.layers, onPressed: () {}),
                ],
              ),
            ),
            
          // Route info for ambulance
          if (isAmbulance)
            Positioned(
              bottom: 10,
              left: 10,
              right: 10,
              child: Container(
                padding: EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.8),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Row(
                  children: [
                    Icon(Icons.directions, color: Colors.blue),
                    SizedBox(width: 8),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'City Hospital',
                            style: TextStyle(fontWeight: FontWeight.bold),
                          ),
                          Text('3.2 km - 8 min (fastest route)'),
                        ],
                      ),
                    ),
                    Container(
                      padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                      decoration: BoxDecoration(
                        color: Colors.green,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Text(
                        'ACTIVE',
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 12,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }
}

class MapControlButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback onPressed;

  const MapControlButton({
    required this.icon,
    required this.onPressed,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(5),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            blurRadius: 2,
            offset: Offset(0, 1),
          ),
        ],
      ),
      child: IconButton(
        icon: Icon(icon),
        onPressed: onPressed,
        constraints: BoxConstraints.tightFor(width: 36, height: 36),
        padding: EdgeInsets.zero,
      ),
    );
  }
}

class MapElementsPainter extends CustomPainter {
  final bool isAmbulance;
  final bool showAllAmbulances;

  MapElementsPainter({
    required this.isAmbulance,
    required this.showAllAmbulances,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Colors.blue
      ..strokeWidth = 3
      ..style = PaintingStyle.stroke;

    // Draw route
    final path = Path();
    path.moveTo(size.width * 0.2, size.height * 0.8);
    path.quadraticBezierTo(
      size.width * 0.4, size.height * 0.6,
      size.width * 0.6, size.height * 0.5,
    );
    path.quadraticBezierTo(
      size.width * 0.8, size.height * 0.4,
      size.width * 0.8, size.height * 0.2,
    );
    
    canvas.drawPath(path, paint);

    // Draw current location
    final locationPaint = Paint()
      ..color = isAmbulance ? Colors.red : Colors.blue
      ..style = PaintingStyle.fill;
    
    canvas.drawCircle(
      Offset(size.width * 0.2, size.height * 0.8),
      8,
      locationPaint,
    );

    // Draw destination
    final destinationPaint = Paint()
      ..color = Colors.red
      ..style = PaintingStyle.fill;
    
    canvas.drawCircle(
      Offset(size.width * 0.8, size.height * 0.2),
      8,
      destinationPaint,
    );

    // Draw other ambulances if showing all
    if (showAllAmbulances) {
      final ambulancePaint = Paint()
        ..color = Colors.red
        ..style = PaintingStyle.fill;
      
      canvas.drawCircle(
        Offset(size.width * 0.4, size.height * 0.3),
        6,
        ambulancePaint,
      );
      
      canvas.drawCircle(
        Offset(size.width * 0.7, size.height * 0.7),
        6,
        ambulancePaint,
      );
      
      canvas.drawCircle(
        Offset(size.width * 0.3, size.height * 0.5),
        6,
        ambulancePaint,
      );
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) {
    return true;
  }
}

