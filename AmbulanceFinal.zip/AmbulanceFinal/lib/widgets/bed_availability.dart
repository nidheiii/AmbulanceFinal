import 'package:flutter/material.dart';

class BedAvailability extends StatelessWidget {
  final int regularBeds;
  final int regularTotal;
  final int icuBeds;
  final int icuTotal;
  final int traumaBeds;
  final int traumaTotal;
  final int pediatricBeds;
  final int pediatricTotal;

  const BedAvailability({
    required this.regularBeds,
    required this.regularTotal,
    required this.icuBeds,
    required this.icuTotal,
    required this.traumaBeds,
    required this.traumaTotal,
    required this.pediatricBeds,
    required this.pediatricTotal,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.blue.shade100,
        borderRadius: BorderRadius.circular(10),
      ),
      padding: EdgeInsets.all(12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.bed, color: Colors.blue),
              SizedBox(width: 8),
              Text(
                'Bed Availability',
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 16,
                ),
              ),
            ],
          ),
          Divider(),
          Expanded(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                _buildBedTypeRow(
                  label: 'Regular',
                  available: regularBeds,
                  total: regularTotal,
                  color: Colors.green,
                ),
                _buildBedTypeRow(
                  label: 'ICU',
                  available: icuBeds,
                  total: icuTotal,
                  color: Colors.red,
                ),
                _buildBedTypeRow(
                  label: 'Trauma',
                  available: traumaBeds,
                  total: traumaTotal,
                  color: Colors.orange,
                ),
                _buildBedTypeRow(
                  label: 'Pediatric',
                  available: pediatricBeds,
                  total: pediatricTotal,
                  color: Colors.purple,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBedTypeRow({
    required String label,
    required int available,
    required int total,
    required Color color,
  }) {
    final percentage = (available / total * 100).round();
    
    return Row(
      children: [
        SizedBox(
          width: 80,
          child: Text(
            label,
            style: TextStyle(fontWeight: FontWeight.bold),
          ),
        ),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Text(
                    '$available/$total',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      color: available > 0 ? Colors.black : Colors.red,
                    ),
                  ),
                  Spacer(),
                  Text(
                    '$percentage%',
                    style: TextStyle(
                      fontSize: 12,
                      color: Colors.grey,
                    ),
                  ),
                ],
              ),
              SizedBox(height: 4),
              LinearProgressIndicator(
                value: available / total,
                backgroundColor: Colors.grey.shade300,
                valueColor: AlwaysStoppedAnimation<Color>(color),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

